<?php
$user=$_SESSION['user'];
extract($_POST);
if(isset($update))
{
	$img=$_FILES['f']['name'];
$query="update users set image='$img' where email='".$_SESSION['user']."'";
mysqli_query($conn,$query);

move_uploaded_file($_FILES['f']['tmp_name'],"../images/".$_SESSION['user']."/".$_FILES['f']['name']);
$err="<font color='blue'>Profie Pic updated successfully !!</font>";
}
$sql=mysqli_query($conn,"select * from users where email='".$_SESSION['user']."'");
$res=mysqli_fetch_assoc($sql);

?>


<h2 align="center">Update Profile Picture</h2>
    <form method="post" enctype="multipart/form-data">
	    <table class="table table-bordered">
		<tr>
		<td colspan="2" ><?php echo @$err;?></td>
		</tr>
		<tr>
		   <td>Choose Your Picture</td>
           <td><input class="form-control" type="file" name="f"/></td>
		   </tr>
		<tr>
		   <td colspan="2" align="center">
		   <input type="submit" class="btn btn-default" value="Update Profile Picture" name="update" style="background:green"/>
		   </td>
		</tr>
	</table>
</form>