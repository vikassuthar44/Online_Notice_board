<?php
extract($_POST);
if(isset($save))
{
	if($np==""||$op==""||$cp=="")
	{
		$err="<font color='red'>fill all the field first</font>";
	}
	else
	{
		$sql=mysqli_query($conn,"select * from users where password='$op'");
		$r=mysqli_num_rows($sql);
		if($r==true)
		{
			if($np==$cp)
			{
				$sql=mysqli_query($conn,"update users set password='$np' where email='$user'");
				$err="<font color='blue'>Password Updated</font>";
			}
			else
			{
				$err="<font color='red'>Password not matched with confirm password</font>";
			}
		}
	    else
		{
			$err="<font color='red'>Wrong Old Password</font>";
		}
	}
}
?>
<h2><font color="blue">Update Password</font></h2>
<form method="POST" >
     <div class="row">
	 <div class="col-md-4"></div>
	 <div class="col-md-4"><?php echo @$err;?></div>
	 </div>
	 
	 <div class="row">
	 <div class="col-md-4">Enter your old password</div>
	 <div class="col-md-5">
	 <input type="password" name="op" class="form-control">
	 </div></div>
	 <div class="row">
	 <div class="col-md-4">Enter your new password</div>
	 <div class="col-md-5">
	 <input type="password" name="np" class="form-control">
	 </div></div>
	 <div class="row">
	 <div class="col-md-4">Enter your confirm password</div>
	 <div class="col-md-5">
	 <input type="password" name="cp" class="form-control">
	 </div></div>
	 
	 <div class="row" style="margin-top:10px">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
		
		
		<input type="submit" value="Update Password" name="save" class="btn btn-success"/>
		<input type="reset" class="btn btn-success"/>
		</div>
	</div>
	</form>