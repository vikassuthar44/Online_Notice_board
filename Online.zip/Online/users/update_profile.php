<?php
extract($_POST);
if(isset($update))
{
	//dob
	$dob=$dd."".$mm."".$yy;
	
	//hobbies
	$hob=implode(",",$hob);
	//$hob="singing";
	//update values
	$query="update users set name='$n',mobile='$mob',gender='$gen',hobbies='$hob',dob='$dob' where email='".$_SESSION['user']."'";

	mysqli_query($conn,$query);
	
	$err="<font color='blue'>Update profile successfully</font>";
}

   //select old data
   //check user already exist or not 
   $sql=mysqli_query($conn,"select * from users where email='".$_SESSION['user']."'");
   $res=mysqli_fetch_assoc($sql);
   
?>
<h2>Update your profile</h2>
    
	 <form method="POST">
	 
	   <table class="table table-bordered">
	   <tr>
	   <td colspan="2"><?php echo @$err;?></td>
	   </tr>
	     <tr>
		 <td>Enter Your Name</td>
		 <td><input type="text" class="form-control" value="<?php echo $res['name']?>" name="n"/></td>
		 </tr>
		 <td>Enter Your Email</td>
		 <td><input type="email" class="form-control" value="<?php echo $res['email']?>" name="e"/></td>
		 </tr>
		 <td>Enter Your Mobile No.</td>
		 <td><input type="text" class="form-control" value="<?php echo $res['mobile_no']?>" name="mob"/></td>
		 </tr>
		 
		 <tr>
		 <td>Select Your Gender</td>
		 <td>
		 Male<input type="radio" <?php if($res['gender']=="male"){echo "checked";}?> name="gen" value="m"/>
		 Female<input type="radio" <?php if($res['gender']=="female"){echo "checked";}?> name="gen" value="f"/>
		 </td>
		 </tr>
		 
				<tr>
					<td>Choose Your hobbies</td>
					<Td>
					<?php 
					$arrr=explode(",",$res['hobbies']);
					?>
					
					
					Reading<input value="reading" <?php if(in_array("reading",$arrr)){echo "checked";} ?> type="checkbox" name="hob[]"/>
					Singing<input value="singin" <?php if(in_array("singing",$arrr)){echo "checked";} ?> type="checkbox" name="hob[]"/>
					Playing<input value="playing" <?php if(in_array("playing",$arrr)){echo "checked";} ?> type="checkbox" name="hob[]"/>
					</td>
				</tr>
		 <tr> 
		 <td>Enter Your DOB</td>
		 <?php
		 $arr1=explode("-",$res['dob']);
		 ?>
		 <td>
		 <select class="form-control" style="width:100px;float:left" name="yy">
		 <option value="">Year</option>
		 <?php
		 for($i=1950;$i<=2017;$i++)
		 {
			 ?><option <?php if($arr1[0]==$i){echo "selected";}?>><?php echo $i;?></option>
			 <?php
		 }
		 ?>
		 </select>
		 <select class="form-control" style="width:100px;float:left" name="mm">
		 <option value="">Month</option>
		 <?php
		 for($i=1;$i<=12;$i++)
		 {?>
			<option <?php if($arr1[1]==$i){echo "selected";}?>><?php echo $i;?></option> 
		 <?php
		 }
		 ?>
		 </select>
		 <select class="form-control" style="width:100px;float:left" name="dd">
		 <option value="">Day</option>
		 <?php
		 for($i=1;$i<=31;$i++)
		 {?>
			<option <?php if($arr1[2]==$i){echo "selected";} ?>><?php echo $i;?></option>
			<?php
		 }
		 ?>
		 </select>
		 </td>
		 </tr>
		 	
				<tr>
					
					
<Td colspan="2" align="center">
<input type="submit" class="btn btn-default" value="Update My Profile" name="update" style="background:green"/>
<input type="reset" class="btn btn-default" value="Reset" style="background:green"/>
				
					</td>
				</tr>
			</table>
		</form>
	