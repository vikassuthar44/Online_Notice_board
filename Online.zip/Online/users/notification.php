<?php
$user=$_SESSION['user'];
//$query="select * from notice where user='$user'";
  //  echo $query;
//echo "sqldfsf===========".$query;
$sql =mysqli_query($conn, "select * from notice where user='$user'");
//echo "sqldfsf===========".$sql;
$r=mysqli_num_rows($sql);
//echo "sqldfsf===========".$r;
if(!$r)
{
	echo"<h2 style='color:red'>No Any Notice For You!!!</h2>";
	//echo "".$_SESSION['user'];
}
else
{
	?>
	<h2>All Notifications:-</h2>
	<table class="table table-bordered">
	<tr class="success">
	<th>Sr. No</th>
	<th>Subject</th>
	<th>Details</th>
	<th>Date</th>
<?php
$i=1;
while($row=mysqli_fetch_assoc($sql))
{
echo "<tr>";
echo "<td>".$i."</td>";
echo "<td>".$row['subject']."</td>";
echo "<td>".$row['description']."</td>";
echo "<td>".$row['date']."</td>";

echo "</tr>";
$i++;
}
?>
	</table>
<?php
echo $row;
	}
?>