<?php 
session_start();
include('connection.php');
//require('connection.php');
extract($_POST);
if(isset($save))
{
	if($e=="" || $p=="")
	{
	$err="<font color='red'>fill all the fields first</font>";	
	}
	else
	{
		if($e=="admin@gmail.com")
		{
			$query="select * from admin where name='$e' and password='$p'";
           $sql=mysqli_query($conn,$query);
        if(mysqli_num_rows($sql)>=1)
        {

           $_SESSION['admin']=$e;
           header('location:admin');
		}
		else{}
		}
		else
		{
 $query="select * from users where email='$e' and password='$p'";
 $sql=mysqli_query($conn,$query);
if(mysqli_num_rows($sql)>=1)
{

$_SESSION['user']=$e;
header('location:users');
}
else
{
$err="<font color='red'>Invalid login details</font>";
}
}
}
}

?>
<h2 style="color:blue"><u><center>Login Form:-</center></u></h2>
<form method="post">
	
	<div class="row">
		<div class="col-sm-4"></div>
		<div class="col-sm-4"><?php echo @$err;?></div>
	</div>
	
	
	
	<div class="row">
		<div class="col-sm-4">Enter Your Email</div>
		<div class="col-sm-5">
		<input type="email" name="e" class="form-control"/></div>
	</div>
	
	<div class="row">
		<div class="col-sm-4">Enter Your Password</div>
		<div class="col-sm-5">
		<input type="password" name="p" class="form-control"/></div>
	</div>
	<div class="row" style="margin-top:10px">
		<div class="col-sm-2"></div>
		<div class="col-sm-8">
		<input type="submit" value="Login" name="save" class="btn btn-success"/>
		
		</div>
	</div>
</form>	