<?php
include('../connection.php');
$nid=$_GET['user_id'];
$sql=mysqli_query($conn,"delete from users where user_id='$nid'");
header('location:index.php?page=manage_users');
?>