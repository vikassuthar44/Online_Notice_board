<?php
$sql=mysqli_query($conn,"select * from users");
$res=mysqli_num_rows($sql);
if(!$res)
{
	echo "<h2 style='color:blue'>No any User Exists</h2>";
}
else
{
?>
<script>
	function DeleteUser(user_id)
	{
		if(confirm("You want to delete this record ?"))
		{
		window.location.href="delete_user.php?user_id="+user_id;
		}
	}
</script>  
 <h2 style="color:#00FFCC">All Users</h2>

    <table class="table table-bordered">
	<tr class="success">
	    <th>Sr.No</th>
		<th>User Name</th>
		<th>Email</th>
		<th>Mobile</th>
		<th>Gender</th>
		<th>Delete</th>
	</tr>
	
	<?php
	$i=1;
	while($row=mysqli_fetch_assoc($sql))
	{
		echo "<tr>";
		echo "<td>".$i."</td>";
		echo "<td>".$row['name']."</td>";
		echo "<td>".$row['email']."</td>";
		echo "<td>".$row['mobile_no']."</td>";
		echo "<td>".$row['gender']."</td>";
	 
	 ?>
	 <td><a href="javascript:DeleteUser('<?php echo $row['user_id']; ?>')" style='color:Red'>delete
	 <span class='glyphicon glyphicon-trash'></span></a></td> 
	 </td>
	 <?php
	    echo "</tr>";
       $i++;
	}
?>
</table>
<?php
}
?>