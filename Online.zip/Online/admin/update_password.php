<?php
extract($_POST);
if(isset($update))
{
	if($op=="" || $np=="" || $cp=="")
	{
		$err="<font color='red'>fill all the filed first</font>";
	}
	else
	{
	$sql=mysqli_query($conn,"select * from admin where password='$op'");
    $res=mysqli_num_rows($sql);
     
     if($res==true)
	 {
		 if($np==$cp)
		 {
			 $sql=mysqli_query($conn,"update admin set password='$np' where name='$admin'");
			 $err="<font color='blue'>Password Update</font>";
		 }
		 else
		 {
			 $err="<font color='red'>New Passowrd not Matched with Confirm Passowrd</font>";
		 }
	 }
     else
	 {
		 $err="<font color='red'>Wrong Old Passowrd</font>";
	 }	 
	}
}
?>

<h2 style="color:blue">Update Password</h2>

    <form method="post">
	
	   <div class="row">
	   <div class="col-md-4"></div>
	   <div class="col-md-5"><?php echo @$err;?></div>
	   </div>
	   
	   <div class="row">
	   <div class="col-md-4">Enter Your Old Passowrd</div>
	   <div class="col-md-5">
	   <input type="password" name="op" class="form-control"></div>
	   </div>
	   
	   <div class="row">
	   <div class="col-md-4">Enter Your New Passowrd</div>
	   <div class="col-md-5">
	   <input type="password" name="np" class="form-control"></div>
	   </div>
	   
	   <div class="row">
	   <div class="col-md-4">Enter Your Confirm Passowrd</div>
	   <div class="col-md-5">
	   <input type="password" name="cp" class="form-control"></div>
	   </div>
	   
	   <div class="row" style="margin-top:10px">
	   <div class="col-md-2"></div>
	   <div class="col-md-8">
	   <input type="submit" value="Update Passowrd" name="update" class="btn btn-success">
	   <input type="reset"  class="btn btn-success">
	   </div>
	   <div>
	 </form>
	   
	   