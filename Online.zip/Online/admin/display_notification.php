<script>
     function DeleteNotice(user_id)
	 {
		 if(confirm("You want to delete this record"))
		 {
			 window.location.href="delete_notice.php?user_id="+user_id;
		 }
	 }
</script>
<?php
$sql=mysqli_query($conn,"select * from notice");
$res=mysqli_num_rows($sql);
if(!$res)
{
	echo "<h2 style='color:red'>NO any notice</h2>";
}
else
{
?>
<h2 style="color:#00FFCC">ALL Notices</h2>
 
       <table class="table table-bordered">
          <tr>
		      <th colspan="7"><a href="index.php?page=add_notice">Add New Notice</a></th>
          </tr>
         <Tr class="success">
		<th>Sr.No</th>
		<th>User</th>
		<th>Subject</th>
		<th>Details</th>
		<th>Date</th>
		<th>Delete</th>
		<th>Update</th>
	</Tr>		 <tr>
        <?php
		
		$i=1;
		while($row=mysqli_fetch_assoc($sql))
		{
			echo "<tr><td>".$i."</td>";
			echo "<td>".$row['user']."</td>";
			echo "<td>".$row['subject']."</td>";
			echo "<td>".$row['description']."</td>";
			echo "<td>".$row['date']."</td>";
		
         ?>
        <td><a href="javascript:DeleteNotice('<?Php echo $row['user_id'];?>')" style="color:red">delete
		<span class='glyphicon glyphicon-trash'></span></a></td>		 
		
<?php	
echo "<td> <a href='index.php?page=update_notice&user_id=".$row['user_id']."' style='color:green'>update
<span class='glyphicon glyphicon-trash'></span></a></td>" ;
echo "</tr>";
$i++;
}
?>
</table>
<?php
}
?>
